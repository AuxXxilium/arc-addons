#!/bin/sh
#
# Shut down on an ACPI power button event.
#
# The event rule matches "button/power" unanchored so that every board is
# covered, whichever button type it exposes. Boards that expose both a
# fixed-feature button (LNXPWRBN) and a control-method one (PNP0C0C / PBTN)
# emit two events for a single press, and acpid runs every matching rule
# per event, so this script would otherwise power off twice.
#
# A lock directory collapses the duplicate. mkdir is atomic, so the two
# acpid children cannot both take it.

LOCK=/var/run/acpi-power.lock

# Drop a lock left behind by a shutdown that never completed, so a stuck
# lock can never disable the button for longer than a minute.
if [ -d "${LOCK}" ]; then
  if [ -n "$(find "${LOCK}" -maxdepth 0 -mmin +1 2>/dev/null)" ]; then
    rmdir "${LOCK}" 2>/dev/null
  fi
fi

if ! mkdir "${LOCK}" 2>/dev/null; then
  exit 0
fi

logger -p err "Shutdown from ACPI"
/usr/syno/sbin/synopoweroff

# Reaching here means the shutdown did not take: hold the lock long enough
# to swallow the duplicate event, then release it so the button still works.
sleep 10
rmdir "${LOCK}" 2>/dev/null
